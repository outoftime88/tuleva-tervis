# Tuleva Enesekindlustus

## Eesmärk
Luua eestikeelne, ühe lehega häkatoniprotoüüp, mis selgitab enesekindlustuse mudelit ja laseb kasutajal oma kaitset kohe arvutada.

## Lehe ülesehitus
- Esmane vaade tugeva sõnumi, lühiselgituse ja kalkulaatorini viiva nupuga.
- Reaalajas kalkulaator kuumakse, kaitse-eesmärgi ja perioodi sisenditega ning selgelt nähtava 85/15 jaotusega.
- Tulemused: isiklik puhver, investeerimistulu, riskifondi maksed, oma kaitse osakaal, ühistu lisagarantii ja täieliku iseseisva kaitse aasta.
- Klassikalise elukindlustuse ja Tuleva mudeli visuaalne võrdlus.
- Kolme sammuga selgitus, kuidas mudel töötab.
- Kalkulaatoriga seotud, nimevälja ja automaatse kehtivusajaga kaitsesertifikaadi näidis.
- Demoversiooni PDF-nupp koos eestikeelse teavitusega ning nõutud vastutuse välistus jaluses.

## Kujundus
- Hele, usaldusväärne fintech-ilme: sügav roheline, värske mündiroheline, soe hele taust ja rohke õhuruum.
- Selge tüpograafia, kompaktsed ikoonid, õrnad liikumised ja sujuv kerimine.
- Mobiilist lähtuv paigutus, mis kasutab suuremal ekraanil kalkulaatori ja tulemuste kõrvutamist.

## Tehnilised detailid
- Arvutusvalemid eraldi abimoodulis: 85% isiklik osa, 15% riskifond ja 5% aastane liitintress igakuiste sissemaksete lihtsustatud mudelina.
- Kalkulaator, võrdlus, tööpõhimõtte plokid ja sertifikaat eraldi Reacti osadena.
- Kõik toimib brauseris ilma sisselogimise, serveri või võtmeteta.
- Ligipääsetavad sisendid, abitekstid, klaviatuuriga kasutatavad juhtnupud ja vähendatud liikumise eelistuse tugi.
- Lehe spetsiifilised otsingumootori ja jagamise metaandmed.
